// src/components/admin/products/EditProductTabs/MediaTab.tsx

'use client';

import { ProductFormState } from '@/app/admin/products/productFormTypes';
import ProductImageUploader from '@/components/admin/ProductImageUploader';

interface MediaTabProps {
  productId: string;
  form: ProductFormState;
  setForm: (f: ProductFormState) => void;
}

type ProductImageMeta = {
  id?: string;
  url?: string; // large
  url_medium?: string; // 1200x800
  url_thumb?: string; // 600x400
  fileName?: string;
  alt?: string;
  title?: string;
  type?: string; // "cover" | "gallery" | ...
  isPrimary?: boolean;
  aiTags?: string[];
  aiDescription?: string;
  aiContext?: string;
};

export default function MediaTab({ productId, form, setForm }: MediaTabProps) {
  const images = (form.images || []) as ProductImageMeta[];

  // URL preview cho ảnh chính:
  // 1) form.mainImageUrl nếu có
  // 2) ảnh isPrimary trong images (url large)
  // 3) ảnh đầu tiên trong images (url large)
  const mainPreviewUrl =
    (form.mainImageUrl && form.mainImageUrl.trim()) ||
    images.find((img) => img.isPrimary && img.url)?.url ||
    images[0]?.url ||
    '';

  const handleSetPrimary = (index: number) => {
    const img = images[index];
    if (!img || !img.url) return;

    const updatedImages = images.map((im, idx) => ({
      ...im,
      isPrimary: idx === index,
    }));

    setForm({
      ...form,
      images: updatedImages,
      // Đồng bộ main_image_url với ảnh primary (large)
      mainImageUrl: img.url,
    });
  };

  const handleCopyUrl = async (url?: string) => {
    if (!url) return;
    try {
      await navigator.clipboard.writeText(url);
      console.log('Copied image URL:', url);
    } catch (err) {
      console.error('Cannot copy to clipboard', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* 1. ẢNH CHÍNH */}
      <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-gray-900">
          Main product image
        </h3>
        <p className="mt-1 text-xs text-gray-500">
          This is the main image displayed on the product page (
          <code>main_image_url</code>). It usually matches the{' '}
          <strong>Primary</strong> image below.
        </p>

        <div className="mt-4 grid gap-4 md:grid-cols-[minmax(0,1.3fr)_minmax(0,1.2fr)]">
          {/* Preview ảnh chính */}
          <div>
            <div className="relative overflow-hidden rounded-lg border border-gray-200 bg-gray-50">
              {mainPreviewUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={mainPreviewUrl}
                  alt="Main image"
                  className="h-full w-full max-h-[260px] object-contain bg-gradient-to-br from-gray-100 via-white to-gray-200"
                />
              ) : (
                <div className="flex h-40 items-center justify-center text-xs text-gray-400">
                  No main image selected
                </div>
              )}
            </div>
            <p className="mt-2 text-[11px] text-gray-500">
              You can choose any image below and click{' '}
              <span className="font-semibold">“Set as Primary”</span> to update
              this main image.
            </p>
          </div>

          {/* Input main_image_url (advanced) */}
          <div>
            <label className="block text-sm font-medium text-gray-700">
              Main image URL (main_image_url)
            </label>
            <input
              type="text"
              className="mt-1 block w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm text-gray-900 placeholder-gray-400 shadow-sm focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              value={form.mainImageUrl}
              onChange={(e) =>
                setForm({ ...form, mainImageUrl: e.target.value })
              }
              placeholder="https://cdn.aiotautotech.com/images/..."
            />
            <p className="mt-1 text-xs text-gray-500">
              Usually you don&apos;t need to edit this manually. When you pick a
              Primary image below, this field will be updated automatically.
            </p>
          </div>
        </div>
      </div>

      {/* 2. DANH SÁCH ẢNH ĐÃ UPLOAD (SOURCE OF TRUTH) */}
      <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-gray-900">
          Uploaded images (Cloudflare R2)
        </h3>
        <p className="mt-1 text-xs text-gray-500">
          All image metadata is stored under the <code>images</code> field of
          the product. Each image may have multiple sizes (<code>url</code>,{' '}
          <code>url_medium</code>, <code>url_thumb</code>).
        </p>

        {images.length === 0 ? (
          <p className="mt-3 text-sm text-gray-400">
            No images uploaded for this product yet.
          </p>
        ) : (
          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {images.map((img, idx) => {
              const urlLarge = img.url || '';
              const urlMedium = img.url_medium || urlLarge;
              const urlThumb = img.url_thumb || urlMedium;

              const displayUrl = urlThumb || urlMedium || urlLarge;
              const shortUrl =
                displayUrl.length > 50
                  ? displayUrl.slice(0, 47) + '...'
                  : displayUrl;

              return (
                <div
                  key={img.id || displayUrl || idx}
                  className="flex flex-col overflow-hidden rounded-lg border border-gray-200 bg-gray-50"
                >
                  <div className="relative bg-black/5">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    {displayUrl ? (
                      <img
                        src={displayUrl}
                        alt={img.alt || img.title || 'Uploaded image'}
                        className="h-32 w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-32 items-center justify-center text-xs text-gray-400">
                        No URL
                      </div>
                    )}
                  </div>

                  <div className="flex flex-1 flex-col gap-1 p-3 text-xs text-gray-700">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold">
                        {img.title || img.fileName || 'Untitled image'}
                      </span>
                      {img.isPrimary && (
                        <span className="inline-flex items-center rounded-full bg-blue-100 px-2 py-0.5 text-[10px] font-medium text-blue-700">
                          Primary
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-500">
                      Type: <span className="font-mono">{img.type || '—'}</span>
                    </p>
                    <p className="text-[11px] text-gray-500">
                      Thumb:{' '}
                      <span className="font-mono break-all text-gray-700">
                        {shortUrl || '—'}
                      </span>
                    </p>

                    <div className="mt-2 flex flex-wrap gap-1">
                      <button
                        type="button"
                        onClick={() => handleSetPrimary(idx)}
                        className="inline-flex items-center rounded-full border border-gray-300 bg-white px-2 py-1 text-[11px] font-medium text-gray-700 hover:border-blue-500 hover:text-blue-600"
                      >
                        Set as Primary
                      </button>
                      <button
                        type="button"
                        onClick={() => handleCopyUrl(urlLarge || urlMedium)}
                        className="inline-flex items-center rounded-full border border-gray-200 bg-gray-100 px-2 py-1 text-[11px] font-medium text-gray-600 hover:border-gray-400"
                      >
                        Copy large URL
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 3. UPLOAD ẢNH MỚI */}
      <div className="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-gray-900">
          Upload new images
        </h3>
        <p className="mt-1 mb-2 text-xs text-gray-500">
          Select images, fill in SEO-friendly file name, alt, title, type,
          isPrimary, AI tags... Then upload. Backend will:
          <br />– resize to 3:2 in multiple sizes (large / medium / thumb)
          <br />– upload to Cloudflare R2
          <br />– update metadata in Firestore (<code>products/:id/images</code>
          ).
        </p>
        <ProductImageUploader
          productId={productId}
          onUploaded={(newImages) =>
            setForm({
              ...form,
              images: newImages,
            })
          }
        />
      </div>
    </div>
  );
}
