// src/app/diy-maker/[idSlug]/components/ProductMediaAndPrice.tsx

interface ProductMediaAndPriceProps {
  title: string;
  mainImage?: string;
  galleryUrls?: string[];
  base_price?: number | null;
  currency?: string;
  sku?: string;
  product_type?: string;
  stock_tracking?: boolean;
  stock_qty?: number | null;
  min_order_qty?: number | null;
  tags?: string[];
}

function formatPrice(base_price?: number | null, currency?: string): string {
  if (base_price === null || base_price === undefined) return 'Chưa cập nhật';
  const cur = currency || 'VND';
  const formatted = base_price.toLocaleString('vi-VN');
  if (cur === 'VND') return `${formatted}₫`;
  return `${formatted} ${cur}`;
}

export function ProductMediaAndPrice(props: ProductMediaAndPriceProps) {
  const {
    title,
    mainImage,
    galleryUrls,
    base_price,
    currency,
    sku,
    product_type,
    stock_tracking,
    stock_qty,
    min_order_qty,
    tags,
  } = props;

  const priceLabel = formatPrice(base_price, currency);

  const allImages = [mainImage, ...(galleryUrls || [])].filter(
    (v, idx, arr) => v && arr.indexOf(v) === idx
  ) as string[];

  const primaryImage = allImages[0];

  return (
    <div className="grid gap-4 rounded-2xl border border-gray-800 bg-[#050608] p-4 shadow-[0_18px_40px_rgba(0,0,0,0.45)] md:grid-cols-[minmax(0,1.4fr)_minmax(0,1.1fr)]">
      {/* Media */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-center rounded-xl border border-gray-800 bg-gradient-to-br from-gray-900 via-black to-gray-900 px-3 py-4">
          {primaryImage ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={primaryImage}
              alt={title || 'Ảnh sản phẩm'}
              className="max-h-[320px] w-full object-contain"
            />
          ) : (
            <div className="flex h-[220px] w-full items-center justify-center text-xs text-gray-500">
              Chưa có ảnh sản phẩm
            </div>
          )}
        </div>

        {allImages.length > 1 && (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {allImages.slice(1).map((url) => (
              <div
                key={url}
                className="relative h-16 w-24 flex-shrink-0 overflow-hidden rounded-lg border border-gray-800 bg-gray-950/70"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={url}
                  alt={title}
                  className="h-full w-full object-cover"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Price & info */}
      <div className="flex flex-col gap-4 rounded-xl border border-gray-800 bg-black/40 p-4 text-sm text-gray-200">
        <div>
          <h2 className="text-base font-semibold text-gray-50">{title}</h2>
          {sku && (
            <p className="mt-1 text-xs text-gray-400">
              SKU: <span className="font-mono text-gray-200">{sku}</span>
            </p>
          )}
        </div>

        <div className="space-y-2 rounded-lg border border-gray-800 bg-black/40 p-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-400">Giá bán</span>
            <span className="text-base font-semibold text-blue-400">
              {priceLabel}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs text-gray-300">
            <div className="flex flex-col gap-1">
              <span className="text-[11px] text-gray-500">Loại</span>
              <span className="inline-flex items-center rounded-full bg-gray-900 px-2 py-0.5 text-[11px]">
                {product_type || 'simple'}
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[11px] text-gray-500">Tồn kho</span>
              <span className="text-[13px]">
                {stock_tracking === false
                  ? 'Không theo dõi'
                  : typeof stock_qty === 'number'
                  ? `${stock_qty} pcs`
                  : 'Chưa rõ'}
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-[11px] text-gray-500">Min. order</span>
              <span className="text-[13px]">
                {typeof min_order_qty === 'number' ? min_order_qty : 1} pcs
              </span>
            </div>
          </div>
        </div>

        {tags && tags.length > 0 && (
          <div className="space-y-1">
            <p className="text-xs font-medium text-gray-400">Tags</p>
            <div className="flex flex-wrap gap-1">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center rounded-full border border-gray-700 bg-gray-900 px-2 py-0.5 text-[11px] text-gray-300"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
