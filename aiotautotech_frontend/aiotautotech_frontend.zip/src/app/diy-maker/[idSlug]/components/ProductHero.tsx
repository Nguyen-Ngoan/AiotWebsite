// src/app/diy-maker/[idSlug]/components/ProductHero.tsx

import Link from "next/link";

interface ProductHeroProps {
  title?: string;
  shortDescription?: string;
  status?: string;
  statusLabel: string;
  productType?: string;
}

export function ProductHero({ title, shortDescription, status, statusLabel, productType }: ProductHeroProps) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <div className="space-y-2">
        <nav className="text-xs text-gray-500">
          <Link href="/" className="hover:text-gray-300">
            Trang chủ
          </Link>
          <span className="mx-1">/</span>
          <Link href="/diy-maker" className="hover:text-gray-300">
            DIY &amp; Maker
          </Link>
          <span className="mx-1">/</span>
          <span className="text-gray-300">Chi tiết sản phẩm</span>
        </nav>
        <h1 className="text-2xl font-semibold leading-tight text-gray-100 sm:text-3xl">{title || "Sản phẩm chưa đặt tên"}</h1>
        {shortDescription && <p className="max-w-2xl text-sm text-gray-400">{shortDescription}</p>}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {status && <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-medium ${status === "active" ? "bg-emerald-500/10 text-emerald-300 ring-1 ring-emerald-500/40" : status === "archived" ? "bg-red-500/10 text-red-300 ring-1 ring-red-500/40" : "bg-gray-700/40 text-gray-200 ring-1 ring-gray-500/40"}`}>{statusLabel}</span>}
        {productType && <span className="inline-flex items-center rounded-full bg-gray-800 px-3 py-1 text-xs text-gray-200">{productType === "bundle" ? "Bundle / Kit" : productType === "service" ? "Dịch vụ" : "Sản phẩm DIY / linh kiện"}</span>}
      </div>
    </div>
  );
}
