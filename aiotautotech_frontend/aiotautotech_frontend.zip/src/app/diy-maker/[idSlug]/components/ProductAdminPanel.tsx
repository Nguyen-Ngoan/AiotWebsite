// src/app/diy-maker/[idSlug]/components/ProductAdminPanel.tsx

import Link from 'next/link';
import { PencilSquareIcon } from '@heroicons/react/24/outline';

interface ProductAdminPanelProps {
  id: string;
  slug?: string;
  sku?: string;
  product_type?: string;
  status?: string;
  created_at?: string;
  updated_at?: string;
}

function formatDate(dateStr?: string): string {
  if (!dateStr) return '';
  try {
    const date = new Date(dateStr);
    return date.toLocaleString('vi-VN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
}

export function ProductAdminPanel({
  id,
  slug,
  sku,
  product_type,
  status,
  created_at,
  updated_at,
}: ProductAdminPanelProps) {
  return (
    <details
      className="rounded-2xl border border-gray-800 bg-[#050608] p-4 text-xs text-gray-300"
      open
    >
      <summary className="flex items-center justify-between gap-3 cursor-pointer list-none text-sm font-semibold text-gray-100">
        <span>Thông tin nội bộ (Admin)</span>

        <Link
          href={`/admin/products/${id}/edit`}
          className="inline-flex items-center gap-1 rounded-full border border-gray-700 px-2 py-1 text-[11px] font-medium text-gray-200 hover:bg-gray-800"
        >
          <PencilSquareIcon className="h-4 w-4" />
          <span>Edit</span>
        </Link>
      </summary>

      <div className="mt-3 space-y-1 border-top border-gray-800 pt-3">
        <p>
          <span className="text-gray-500">ID Firestore: </span>
          <span className="font-mono text-[11px] text-gray-200">{id}</span>
        </p>
        {slug && (
          <p>
            <span className="text-gray-500">Slug: </span>
            <span className="text-gray-200">{slug}</span>
          </p>
        )}
        {sku && (
          <p>
            <span className="text-gray-500">SKU: </span>
            <span className="text-gray-200">{sku}</span>
          </p>
        )}
        {product_type && (
          <p>
            <span className="text-gray-500">Product type: </span>
            <span className="text-gray-200">{product_type}</span>
          </p>
        )}
        {status && (
          <p>
            <span className="text-gray-500">Status: </span>
            <span className="text-gray-200">{status}</span>
          </p>
        )}
        <p>
          <span className="text-gray-500">Created at: </span>
          <span className="text-gray-200">{formatDate(created_at)}</span>
        </p>
        <p>
          <span className="text-gray-500">Updated at: </span>
          <span className="text-gray-200">{formatDate(updated_at)}</span>
        </p>
      </div>
    </details>
  );
}
