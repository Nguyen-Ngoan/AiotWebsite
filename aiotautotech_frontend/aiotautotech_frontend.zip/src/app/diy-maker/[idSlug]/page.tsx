// src/app/diy-maker/[idSlug]/page.tsx

import { ProductDetailPageImpl } from "./ProductDetailPage";

export default async function Page(props: { params: Promise<{ idSlug: string }> }) {
  return <ProductDetailPageImpl {...props} />;
}
