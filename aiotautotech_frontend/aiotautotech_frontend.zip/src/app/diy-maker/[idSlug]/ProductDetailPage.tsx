// src/app/diy-maker/[idSlug]/ProductDetailPage.tsx

import Link from 'next/link';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { getApiUrl } from '@/lib/apiConfig';

import { ProductHero } from './components/ProductHero';
import { ProductMediaAndPrice } from './components/ProductMediaAndPrice';
import { ProductDescription } from './components/ProductDescription';
import { ProductFeatures } from './components/ProductFeatures';
import { ProductTechDocs } from './components/ProductTechDocs';
import { ProductAdminPanel } from './components/ProductAdminPanel';

export interface ProductSpecItem {
  key?: string;
  value?: string;
}

export interface ProductImage {
  id: string;
  url: string;
  url_medium?: string;
  url_thumb?: string;
  fileName?: string;
  alt?: string;
  title?: string;
  type?: string; // "cover" | "gallery" | ...
  isPrimary?: boolean;
  aiDescription?: string;
  aiTags?: string[];
  aiContext?: string;
}

export interface Product {
  id: string;
  title: string;
  slug?: string;
  short_description?: string;
  description_html?: string;
  product_type?: string;
  status?: 'draft' | 'active' | 'archived' | string;
  base_price?: number | null;
  currency?: string;
  sku?: string;
  stock_tracking?: boolean;
  stock_qty?: number | null;
  min_order_qty?: number | null;
  tags?: string[];
  created_at?: string;
  updated_at?: string;

  // Media cũ
  main_image_url?: string;
  gallery_urls?: string[];

  // Media mới (R2 metadata)
  images?: ProductImage[];

  // Tech docs
  datasheet_url?: string;
  schematic_url?: string;
  step_model_url?: string;
  stl_files_url?: string;
  user_manual_url?: string;
  github_repo_url?: string;

  // Features (snake_case giống backend)
  key_features?: string[];
  use_cases?: string[];
  limitations?: string[];
  compatibility?: string[];
  specs?: ProductSpecItem[];
}

// ======================= FETCH =======================

async function fetchProduct(productId: string): Promise<Product | null> {
  try {
    const res = await fetch(getApiUrl(`/products/${productId}/`), {
      // Revalidate sau 120 giây
      next: { revalidate: 120 },
    });

    if (!res.ok) {
      console.error(
        'Failed to fetch product detail:',
        res.status,
        res.statusText
      );
      return null;
    }

    const data = await res.json();
    return data as Product;
  } catch (err) {
    console.error('Error fetching product detail:', err);
    return null;
  }
}

// ======================= HELPERS =======================

function parseIdFromIdSlug(idSlug: string): string | null {
  if (!idSlug) return null;
  const parts = idSlug.split('-');
  if (!parts.length) return null;
  return parts[0];
}

function formatPrice(base_price?: number | null, currency?: string): string {
  if (base_price === null || base_price === undefined) return 'Chưa cập nhật';
  const cur = currency || 'VND';
  const formatted = base_price.toLocaleString('vi-VN');
  if (cur === 'VND') {
    return `${formatted}₫`;
  }
  return `${formatted} ${cur}`;
}

function getStatusLabel(status?: string): string {
  switch (status) {
    case 'active':
      return 'Đang bán';
    case 'draft':
      return 'Nháp';
    case 'archived':
      return 'Đã ẩn';
    default:
      return status || 'Không rõ';
  }
}

function getTypeLabel(product_type?: string): string {
  switch (product_type) {
    case 'simple':
      return 'Simple';
    case 'bundle':
      return 'Bundle';
    case 'kit':
      return 'Kit';
    default:
      return product_type || 'Khác';
  }
}

function getPrimaryTag(tags?: string[]): string | null {
  if (!tags || tags.length === 0) return null;
  return tags[0];
}

// ======================= MAIN PAGE IMPL =======================

// Next 15: params là Promise => phải await props.params
export async function ProductDetailPageImpl(props: {
  params: Promise<{ idSlug: string }>;
}) {
  const { idSlug } = await props.params;
  const productId = parseIdFromIdSlug(idSlug);

  if (!productId) {
    return (
      <div className="min-h-screen bg-black text-gray-100">
        <Header />
        <main className="mx-auto max-w-4xl px-4 pt-24 pb-10">
          <div className="rounded-2xl border border-red-500/40 bg-red-950/40 px-4 py-6 text-sm text-red-100">
            Không xác định được ID sản phẩm từ URL.
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const product = await fetchProduct(productId);

  if (!product) {
    return (
      <div className="min-h-screen bg-black text-gray-100">
        <Header />
        <main className="mx-auto max-w-4xl px-4 pt-24 pb-10">
          <div className="rounded-2xl border border-red-500/40 bg-red-950/40 px-4 py-6 text-sm text-red-100">
            Không tải được thông tin sản phẩm. Vui lòng thử lại sau.
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const {
    id,
    title,
    slug,
    short_description,
    description_html,
    product_type,
    status,
    base_price,
    currency,
    sku,
    stock_tracking,
    stock_qty,
    min_order_qty,
    tags,
    created_at,
    updated_at,
    main_image_url,
    gallery_urls,
    images,
    datasheet_url,
    schematic_url,
    step_model_url,
    stl_files_url,
    user_manual_url,
    github_repo_url,
    key_features,
    use_cases,
    limitations,
    compatibility,
    specs,
  } = product;

  const priceLabel = formatPrice(base_price, currency);
  const statusLabel = getStatusLabel(status);
  const typeLabel = getTypeLabel(product_type);
  const primaryTag = getPrimaryTag(tags);

  const productImages: ProductImage[] = Array.isArray(images) ? images : [];

  // Ảnh chính: ưu tiên isPrimary, sau đó type = "cover", cuối cùng là phần tử đầu
  const primaryImage =
    productImages.find((img) => img.isPrimary && img.url) ||
    productImages.find((img) => img.type === 'cover' && img.url) ||
    productImages[0];

  // Gallery từ images: ưu tiên url_medium (3:2) nếu có, fallback url
  const galleryFromImages = productImages
    .filter((img) => img && (img.url_medium || img.url))
    .map((img) => img.url_medium || img.url);

  // mainImage & galleryUrls dùng cho component UI:
  // - Nếu backend đã có main_image_url / gallery_urls thì ưu tiên
  // - Nếu không, fallback sang metadata "images"
  const mainImage =
    (main_image_url && main_image_url.trim().length > 0
      ? main_image_url
      : primaryImage?.url) || undefined;

  const galleryUrlsFinal =
    gallery_urls && gallery_urls.length > 0 ? gallery_urls : galleryFromImages;

  const hasAnyFeatures = Boolean(
    (key_features && key_features.length > 0) ||
      (use_cases && use_cases.length > 0) ||
      (limitations && limitations.length > 0) ||
      (compatibility && compatibility.length > 0) ||
      (specs && specs.length > 0)
  );

  const slugPart = slug && slug.trim().length > 0 ? slug : 'san-pham';
  const breadCrumbIdSlug = `${id}-${slugPart}`;

  return (
    <div className="min-h-screen bg-black text-gray-100">
      <Header />

      <main className="mx-auto max-w-6xl px-4 pt-20 pb-10 lg:px-6">
        {/* Breadcrumb */}
        <nav className="mb-4 text-xs text-gray-500">
          <ol className="flex flex-wrap items-center gap-1">
            <li>
              <Link href="/" className="hover:text-gray-200">
                Trang chủ
              </Link>
            </li>
            <li className="text-gray-600">/</li>
            <li>
              <Link href="/diy-maker" className="hover:text-gray-200">
                DIY &amp; Maker
              </Link>
            </li>
            <li className="text-gray-600">/</li>
            <li className="text-gray-300 line-clamp-1 max-w-[220px] sm:max-w-[320px]">
              {title || 'Sản phẩm'}
            </li>
          </ol>
        </nav>

        {/* Hero */}
        <ProductHero
          title={title}
          short_description={short_description}
          priceLabel={priceLabel}
          statusLabel={statusLabel}
          typeLabel={typeLabel}
          primaryTag={primaryTag}
          sku={sku}
          idSlug={breadCrumbIdSlug}
        />

        {/* Nội dung chính */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1.8fr)_minmax(0,1.1fr)]">
          {/* Cột trái */}
          <section className="space-y-4">
            <ProductMediaAndPrice
              title={title}
              mainImage={mainImage}
              galleryUrls={galleryUrlsFinal}
              base_price={base_price}
              currency={currency}
              sku={sku}
              product_type={product_type}
              stock_tracking={stock_tracking}
              stock_qty={stock_qty}
              min_order_qty={min_order_qty}
              tags={tags}
            />

            <ProductDescription descriptionHtml={description_html} />

            <ProductFeatures
              hasAnyFeatures={hasAnyFeatures}
              key_features={key_features}
              use_cases={use_cases}
              limitations={limitations}
              compatibility={compatibility}
              specs={specs}
            />

            <ProductTechDocs
              datasheet_url={datasheet_url}
              schematic_url={schematic_url}
              step_model_url={step_model_url}
              stl_files_url={stl_files_url}
              user_manual_url={user_manual_url}
              github_repo_url={github_repo_url}
            />
          </section>

          {/* Cột phải */}
          <aside className="space-y-4">
            <ProductAdminPanel
              id={id}
              slug={slug}
              sku={sku}
              product_type={product_type}
              status={status}
              created_at={created_at}
              updated_at={updated_at}
            />
          </aside>
        </div>
      </main>

      <Footer />
    </div>
  );
}
