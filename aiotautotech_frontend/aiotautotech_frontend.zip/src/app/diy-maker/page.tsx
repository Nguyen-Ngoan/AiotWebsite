// src/app/diy-maker/page.tsx

import Link from 'next/link';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { getApiUrl } from '@/lib/apiConfig';

interface ProductImage {
  id?: string;
  url?: string;
  url_medium?: string;
  url_thumb?: string;
  fileName?: string;
  alt?: string;
  title?: string;
  type?: string;
  isPrimary?: boolean;
}

interface Product {
  id: string;
  title: string;
  slug?: string;
  short_description?: string;
  description_html?: string;
  product_type?: string;
  status?: 'draft' | 'active' | 'archived' | string;
  base_price?: number | null;
  currency?: string;
  sku?: string;
  stock_tracking?: boolean;
  stock_qty?: number;
  min_order_qty?: number;
  tags?: string[];
  created_at?: string;
  updated_at?: string;

  // Media
  main_image_url?: string;
  gallery_urls?: string[];

  // Media metadata
  images?: ProductImage[];
}

async function fetchProducts(): Promise<Product[]> {
  try {
    const res = await fetch(getApiUrl('/products/'), {
      next: { revalidate: 60 },
    });

    if (!res.ok) {
      console.error('Failed to fetch products:', res.status, res.statusText);
      return [];
    }

    const data = await res.json();
    if (!Array.isArray(data)) return [];
    return data as Product[];
  } catch (err) {
    console.error('Error fetching products:', err);
    return [];
  }
}

function formatPrice(base_price?: number | null, currency?: string): string {
  if (base_price === null || base_price === undefined) return 'Chưa cập nhật';
  const cur = currency || 'VND';
  const formatted = base_price.toLocaleString('vi-VN');
  if (cur === 'VND') {
    return `${formatted}₫`;
  }
  return `${formatted} ${cur}`;
}

function getStatusLabel(status?: string): string {
  switch (status) {
    case 'active':
      return 'Đang bán';
    case 'draft':
      return 'Nháp';
    case 'archived':
      return 'Đã ẩn';
    default:
      return status || 'Không rõ';
  }
}

function getTypeLabel(product_type?: string): string {
  switch (product_type) {
    case 'simple':
      return 'Simple';
    case 'bundle':
      return 'Bundle';
    case 'kit':
      return 'Kit';
    default:
      return product_type || 'Khác';
  }
}

export default async function DiyMakerPage() {
  const products = await fetchProducts();
  const hasProducts = products.length > 0;

  return (
    <div className="min-h-screen bg-black text-gray-100">
      <Header />

      <main className="mx-auto max-w-6xl px-4 py-10 lg:px-6">
        {/* Heading */}
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-gray-400">
              DIY &amp; Maker
            </p>
            <h1 className="text-2xl font-semibold leading-tight text-gray-50 sm:text-3xl">
              Sản phẩm DIY &amp; linh kiện tự động hoá
            </h1>
            <p className="mt-2 max-w-2xl text-sm text-gray-400">
              Các mô-đun DIY, cụm cơ khí, trục tuyến tính, step motor và các hệ
              thống tự động hoá nhỏ.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Link
              href="/"
              className="rounded-full border border-gray-700 bg-black px-3 py-1.5 text-xs font-medium text-gray-300 hover:bg-gray-900"
            >
              ← Về trang chủ
            </Link>
            <Link
              href="/admin/products/new"
              className="rounded-full bg-blue-600 px-4 py-1.5 text-xs font-semibold text-white shadow hover:bg-blue-500"
            >
              + Thêm sản phẩm
            </Link>
          </div>
        </div>

        {/* Không có sản phẩm */}
        {!hasProducts && (
          <div className="rounded-2xl border border-dashed border-gray-700/70 bg-[#050608] px-6 py-10 text-center text-sm text-gray-400">
            Chưa có sản phẩm nào được tạo.
            <br />
            Hãy bấm{' '}
            <span className="font-semibold text-gray-200">
              “+ Thêm sản phẩm”
            </span>{' '}
            ở góc phải để tạo sản phẩm đầu tiên.
          </div>
        )}

        {/* Grid sản phẩm */}
        {hasProducts && (
          <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {products.map((product) => {
              const statusLabel = getStatusLabel(product.status);
              const typeLabel = getTypeLabel(product.product_type);
              const priceLabel = formatPrice(
                product.base_price,
                product.currency
              );

              const primaryImageMeta =
                (product.images && product.images.find((i) => i.isPrimary)) ||
                (product.images && product.images[0]);

              const mainImage =
                primaryImageMeta?.url_thumb ||
                primaryImageMeta?.url_medium ||
                primaryImageMeta?.url ||
                (product.main_image_url &&
                product.main_image_url.trim().length > 0
                  ? product.main_image_url
                  : product.gallery_urls && product.gallery_urls.length > 0
                  ? product.gallery_urls[0]
                  : undefined);

              const slugPart =
                product.slug && product.slug.trim().length > 0
                  ? product.slug
                  : 'san-pham';

              const detailHref = `/diy-maker/${product.id}-${slugPart}`;

              return (
                <div
                  key={product.id}
                  className="flex flex-col rounded-2xl border border-gray-800 bg-[#050608] p-4 shadow-[0_18px_40px_rgba(0,0,0,0.45)]"
                >
                  {/* Vùng ảnh */}
                  {mainImage && (
                    <div className="mb-3 overflow-hidden rounded-xl border border-gray-800 bg-black/60">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={mainImage}
                        alt={product.title || 'Ảnh sản phẩm'}
                        className="h-40 w-full object-contain"
                      />
                    </div>
                  )}

                  {/* Header card */}
                  <div className="mb-3 flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <h2 className="line-clamp-2 text-sm font-semibold text-gray-100 sm:text-base">
                        {product.title || 'Sản phẩm chưa đặt tên'}
                      </h2>
                      {product.sku && (
                        <p className="mt-1 text-[11px] text-gray-500">
                          SKU: {product.sku}
                        </p>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <span
                        className={[
                          'inline-flex rounded-full px-2 py-0.5 text-[10px]',
                          product.status === 'active'
                            ? 'bg-green-900/40 text-green-300 border border-green-700/60'
                            : product.status === 'draft'
                            ? 'bg-yellow-900/40 text-yellow-300 border border-yellow-700/60'
                            : 'bg-gray-900/40 text-gray-300 border border-gray-700/60',
                        ].join(' ')}
                      >
                        {statusLabel}
                      </span>
                      <span className="inline-flex rounded-full bg-gray-900 px-2 py-0.5 text-[10px] text-gray-300">
                        {typeLabel}
                      </span>
                    </div>
                  </div>

                  {/* Mô tả ngắn */}
                  {product.short_description && (
                    <p className="mb-3 text-xs leading-relaxed text-gray-300">
                      {product.short_description}
                    </p>
                  )}

                  {/* Tags */}
                  {product.tags && product.tags.length > 0 && (
                    <div className="mb-3 flex flex-wrap gap-1">
                      {product.tags.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center rounded-full bg-gray-900 px-2 py-0.5 text-[10px] text-gray-400"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Price + stock */}
                  <div className="mt-auto border-t border-gray-800 pt-3 text-xs text-gray-300">
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-gray-400">Giá bán</span>
                      <span className="font-semibold text-blue-400">
                        {priceLabel}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[11px] text-gray-400">
                      <span>
                        Min. order:{' '}
                        {typeof product.min_order_qty === 'number'
                          ? product.min_order_qty
                          : 1}{' '}
                        pcs
                      </span>
                      <span>
                        Tồn kho:{' '}
                        {product.stock_tracking === false
                          ? 'Không theo dõi'
                          : typeof product.stock_qty === 'number'
                          ? `${product.stock_qty} pcs`
                          : 'Chưa rõ'}
                      </span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="mt-3 flex items-center justify-between gap-2 text-xs">
                    <Link
                      href={detailHref}
                      className="inline-flex flex-1 items-center justify-center rounded-full bg-blue-600 px-3 py-1.5 font-medium text-white shadow hover:bg-blue-500"
                    >
                      Xem chi tiết
                    </Link>
                    <Link
                      href={`/admin/products/${product.id}/edit`}
                      className="inline-flex items-center justify-center rounded-full border border-gray-700 bg-black px-3 py-1.5 font-medium text-gray-200 hover:bg-gray-900"
                    >
                      Edit
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
